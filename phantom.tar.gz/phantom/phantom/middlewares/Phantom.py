# -*- coding: utf-8 -*-

from scrapy.exceptions import IgnoreRequest
from scrapy.http import HtmlResponse, Response
from selenium import webdriver


class PhantomMiddlewares(object):
    def process_request(cls, request, spider):
        if 'PhantomJS' in request.meta:
            driver = webdriver.PhantomJS(executable_path='/opt/phantomjs/bin/phantomjs')
            driver.get(request.url)
            content = driver.page_source.encode('utf-8')
            driver.quit()
            return HtmlResponse(request.url, encoding='utf-8', body=content, request=request)
